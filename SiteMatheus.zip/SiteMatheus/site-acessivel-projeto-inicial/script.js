document.getElementById('settingsBtn').addEventListener('click', function() {
    document.getElementById('settingsMenu').style.display = 'block';
});

document.getElementById('closeSettings').addEventListener('click', function() {
    document.getElementById('settingsMenu').style.display = 'none';
});

document.getElementById('zoomLevel').addEventListener('input', function() {
    let zoom = this.value;
    document.getElementById('zoomValue').textContent = zoom + '%';
    document.body.style.fontSize = `${zoom / 100}em`
});
